"use client";

import Photo from "./Photo";
import { getProduct } from "@/lib/products";

/**
 * Product photo (from `image` in src/lib/products.ts).
 * Falls back to a tinted illustration if the photo is missing.
 */
export default function ProductImage({
  slug,
  name,
  palette,
  className = "",
  priority = false,
}: {
  slug: string;
  name: string;
  palette: [string, string];
  className?: string;
  priority?: boolean;
}) {
  const product = getProduct(slug);

  return (
    <div className={`relative overflow-hidden bg-blush ${className}`}>
      <Photo
        src={product?.image}
        alt={name}
        category={product?.category ?? "Sarees"}
        colors={palette}
        priority={priority}
        className="absolute inset-0 h-full w-full transition duration-700 group-hover:scale-105"
      />
    </div>
  );
}
