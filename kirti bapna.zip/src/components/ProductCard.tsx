import Link from "next/link";
import { discountPercent, formatPrice, Product } from "@/lib/products";
import ProductImage from "./ProductImage";

export default function ProductCard({ product }: { product: Product }) {
  const off = discountPercent(product);
  return (
    <Link href={`/product/${product.slug}`} className="group block">
      <div className="relative overflow-hidden rounded-2xl">
        <ProductImage
          slug={product.slug}
          name={product.name}
          palette={product.palette}
          className="aspect-[3/4] w-full rounded-2xl"
        />
        {product.tag && (
          <span className="absolute left-3 top-3 rounded-full bg-white/95 px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-brand shadow-sm">
            {product.tag}
          </span>
        )}
        <div className="pointer-events-none absolute inset-x-3 bottom-3 translate-y-3 rounded-full bg-white/95 py-2.5 text-center text-xs font-medium tracking-wide text-brand opacity-0 shadow transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          View details
        </div>
      </div>
      <div className="mt-4 space-y-1.5 px-1">
        <p className="text-[11px] uppercase tracking-widest text-ink/50">{product.category}</p>
        <h3 className="font-display text-lg leading-snug text-ink">{product.name}</h3>
        <div className="flex items-baseline gap-2">
          <span className="font-semibold text-brand">{formatPrice(product.price)}</span>
          {off > 0 && (
            <>
              <span className="text-sm text-ink/40 line-through">{formatPrice(product.mrp)}</span>
              <span className="text-xs font-medium text-emerald-700">{off}% off</span>
            </>
          )}
        </div>
        <div className="flex gap-1.5 pt-1">
          {product.colors.map((c) => (
            <span
              key={c.name}
              title={c.name}
              className="h-3.5 w-3.5 rounded-full border border-ink/15"
              style={{ background: c.hex }}
            />
          ))}
        </div>
      </div>
    </Link>
  );
}
