"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Photo from "./Photo";
import { MaskLines } from "./motion";
import { banners } from "@/lib/products";

const SLIDE_MS = 5500;

const slides = [
  { label: "Sarees", href: "/shop?category=Sarees", img: banners.Sarees },
  { label: "Kurta Sets", href: "/shop?category=Kurta%20Sets", img: banners["Kurta Sets"] },
  { label: "Co-ord Sets", href: "/shop?category=Co-ord%20Sets", img: banners["Co-ord Sets"] },
  { label: "Lehengas", href: "/shop?category=Lehengas", img: banners.Lehengas },
  { label: "Dresses", href: "/shop?category=Dresses", img: banners.Dresses },
] as const;

const sparkles = [
  ["8%", "18%", "0s", 14], ["22%", "70%", "1.2s", 10], ["46%", "10%", "2.1s", 18], ["58%", "84%", "0.6s", 12],
  ["74%", "30%", "1.7s", 16], ["88%", "62%", "2.6s", 10], ["34%", "46%", "3.2s", 12],
] as const;

const pose = (o: number): React.CSSProperties => {
  if (o === 0) return { transform: "translateX(0) rotate(0deg) scale(1)", opacity: 1, zIndex: 30 };
  if (o === 1) return { transform: "translateX(22%) rotate(7deg) scale(.9)", opacity: 0.85, zIndex: 20 };
  if (o === 2) return { transform: "translateX(40%) rotate(13deg) scale(.8)", opacity: 0.5, zIndex: 10 };
  return { transform: "translateX(0) rotate(-6deg) scale(.85)", opacity: 0, zIndex: 0 };
};

export default function HeroSlider() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused) return;
    const t = setTimeout(() => setI((v) => (v + 1) % slides.length), SLIDE_MS);
    return () => clearTimeout(t);
  }, [i, paused]);

  const current = slides[i];

  return (
    <section
      className="relative min-h-[calc(100svh-72px)] overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* Full-bleed banners */}
      {slides.map((sl, idx) => (
        <div key={sl.label} aria-hidden={idx !== i} className={`absolute inset-0 transition-opacity duration-[1400ms] ease-out ${idx === i ? "opacity-100" : "opacity-0"}`}>
          <div className={`absolute inset-0 ${idx === i ? "kenburns" : ""}`}>
            <Photo src={sl.img} alt={`${sl.label} banner`} category="Sarees" colors={["#D81B60", "#880E4F"]} priority={idx === 0} className="absolute inset-0 h-full w-full" />
          </div>
        </div>
      ))}
      <div className="absolute inset-0 bg-gradient-to-r from-night via-night/60 to-night/10" />
      <div className="absolute inset-0 bg-gradient-to-t from-night via-transparent to-night/50" />

      {/* Twinkling sparkles */}
      {sparkles.map(([l, t, d, size], k) => (
        <span
          key={k}
          aria-hidden="true"
          className="animate-twinkle pointer-events-none absolute text-accent"
          style={{ left: l, top: t, animationDelay: d, fontSize: size }}
        >
          ✦
        </span>
      ))}

      <div className="container-x relative z-10 flex min-h-[calc(100svh-72px)] flex-col justify-end gap-8 pb-24 pt-10 md:pb-16">
        <div>
          <p className="eyebrow mb-6 animate-fadeUp">Kirti Bapna · Ladies Fashion</p>
          <MaskLines
            as="h1"
            hero
            className="font-display text-[clamp(2.2rem,6.2vw,5.6rem)] font-medium uppercase leading-[0.9] tracking-tight text-white"
            lines={["Wear the story,", <span key="b" className="italic">not the trend.</span>]}
          />
          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Link href="/shop" className="btn-primary">Shop the collection</Link>
            <Link href={current.href} className="btn-outline">Explore {current.label}</Link>
          </div>

          <ul className="mt-12 hidden space-y-2 md:block">
            {slides.map((s, idx) => (
              <li key={s.label}>
                <button
                  onClick={() => setI(idx)}
                  aria-label={`Show ${s.label}`}
                  aria-current={idx === i}
                  className={`flex items-center gap-3 text-xs uppercase tracking-widest transition ${idx === i ? "text-white" : "text-white/40 hover:text-white/80"}`}
                >
                  <span>{String(idx + 1).padStart(2, "0")}</span>
                  <span className="relative h-px w-16 overflow-hidden bg-white/20">
                    {idx === i && (
                      <span
                        key={`${i}-${paused}`}
                        className="absolute inset-0 origin-left bg-brand"
                        style={{ animation: `progress ${SLIDE_MS}ms linear both`, animationPlayState: paused ? "paused" : "running" }}
                      />
                    )}
                  </span>
                  <span>{s.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center gap-2 md:hidden">
          {slides.map((s, idx) => (
            <button key={s.label} onClick={() => setI(idx)} aria-label={`Show ${s.label}`} className={`h-1 rounded-full transition-all ${idx === i ? "w-10 bg-brand" : "w-4 bg-white/30"}`} />
          ))}
          <span className="ml-3 text-xs uppercase tracking-widest text-white/60">{current.label}</span>
        </div>
      </div>

      <div className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 md:flex">
        <span className="text-[10px] uppercase tracking-[0.35em] text-white/50">Scroll</span>
        <span className="block h-10 w-px bg-white/60" style={{ animation: "scrollline 2.2s ease-in-out infinite" }} />
      </div>
    </section>
  );
}
