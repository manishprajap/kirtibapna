"use client";

import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import Footer from "./Footer";
import Header from "./Header";

export default function SiteChrome({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith("/admin");

  if (isAdmin) return <div className="admin-canvas">{children}</div>;

  return (
    <div className="site-canvas">
      <Header />
      <main>{children}</main>
      <Footer />
    </div>
  );
}