"use client";

import { useEffect, useState } from "react";
import { BrandMark } from "./Logo";

const finish = () => {
  document.documentElement.dataset.intro = "done";
  // Tell other components (e.g. the newsletter popup) that the loader is gone.
  window.dispatchEvent(new Event("kb-intro-done"));
};

/** Short brand intro shown once per visit. Sets html[data-intro="done"] so hero text can animate in. */
export default function Preloader() {
  const [show, setShow] = useState(true);
  const [out, setOut] = useState(false);

  useEffect(() => {
    let seen = false;
    try {
      seen = sessionStorage.getItem("kb-intro") === "1";
    } catch {
      /* ignore */
    }
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (seen || reduce) {
      setShow(false);
      finish();
      return;
    }
    const t1 = setTimeout(() => setOut(true), 3600);
    const t2 = setTimeout(() => {
      setShow(false);
      finish();
      try {
        sessionStorage.setItem("kb-intro", "1");
      } catch {
        /* ignore */
      }
    }, 4500);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (!show) return null;

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-night transition-transform duration-[800ms] ease-[cubic-bezier(.76,0,.24,1)] ${
        out ? "-translate-y-full" : "translate-y-0"
      }`}
    >
      <div className="animate-fadeUp">
        <BrandMark size={110} id="intro" />
      </div>
      <div className="mt-10 h-px w-40 overflow-hidden bg-white/10">
        <div className="h-full origin-left bg-brand" style={{ animation: "progress 3.4s cubic-bezier(.65,0,.35,1) both" }} />
      </div>
    </div>
  );
}
